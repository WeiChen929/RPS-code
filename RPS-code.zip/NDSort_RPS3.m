function [FrontNo,MaxFNo] = NDSort_RPS3(PopObj,d4,RP,nSort)
% Non-RPD-dominated sorting (based on deductive sort)

    [N,M]   = size(PopObj);
    FrontNo = inf(1,N);
    MaxFNo  = 0;
    while sum(FrontNo<inf) < min(nSort,N)
        MaxFNo = MaxFNo + 1;
        Sorted = FrontNo ~= inf;
        D      = Sorted;
        for i = 1 : N
            if ~D(i)
                for j = i+1 : N
                    if ~D(j)
                        domi = 0;
                        for m = 1 : M
                            if PopObj(i,m) < PopObj(j,m)
                                if domi == -1
                                    domi = 0;
                                    break;
                                else
                                    domi = 1;
                                end
                            elseif PopObj(i,m) > PopObj(j,m)
                                if domi == 1
                                    domi = 0;
                                    break;
                                else
                                    domi = -1;
                                end
                            end
                        end
                        
                        if domi == 0 && RP(i)==RP(j)
                            if d4(i) < d4(j)
                                domi = 1;
                            elseif d4(i) > d4(j)
                                domi = -1;
                            end
                        elseif  domi == 0 && RP(i)~=RP(j)
                            if  RPSet_Density(i) < RPSet_Density(j)
                                domi = 1;
                            elseif  RPSet_Density(i) > RPSet_Density(j)
                                domi = -1;
                            end
                        end                                 
                        if domi == 1
                            D(j) = true;
                        elseif domi == -1
                            D(i) = true;
                            break;
                        end
                    end
                end
                if ~D(i)
                    FrontNo(i) = MaxFNo;
                end
            end
        end
    end
end