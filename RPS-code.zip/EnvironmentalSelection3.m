function [Population,FrontNo,RPSet_Density] = EnvironmentalSelection3(Population,RPSet,N)
% The environmental selection of RPS-NSGA-II
-----------------------------------------------------------------------

    %% Normalization
    PopObj = Population.objs;
    Fmin   = min(PopObj,[],1);
    Fmax   = max(PopObj,[],1);
    PopObj = (PopObj-repmat(Fmin,size(PopObj,1),1))./repmat(Fmax-Fmin,size(PopObj,1),1);
    
    %% Association
    d4  = sum(PopObj,2);
    Cosine  = 1 - pdist2(PopObj,RPSet,'cosine');
    Sine = sqrt(1-Cosine.^2);
    [~,RP] = min(Sine,[],2);
    for i=1:N 
        a=RP(i);
        for j =1:N
        P=find(RP(j)==a);       
        end
        RPSet_Density(i) = numel(P);
    end
 
    %% Favor extreme solutions
    ND              = find(NDSort(PopObj,1)==1);
    [~,Extreme]     = max(PopObj(ND,:),[],1);
    d4(ND(Extreme)) = 0;
       
    %% Non-RPD-dominated sorting
    [FrontNo,MaxFNo] = NDSort_RPS3(PopObj,d4,RP,N);
    Next = FrontNo < MaxFNo;

    %% Select the solutions in the last front
    Last     = find(FrontNo==MaxFNo);
    [~,Rank] = sort(RPSet_Density(Last));
    Next(Last(Rank(1:N-sum(Next)))) = true;
    
    %% Population for next generation
    Population = Population(Next);
    FrontNo    = FrontNo(Next);
    RPSet_Density         = RPSet_Density(Next);
end